import csv
import matplotlib.pyplot as plt 
import numpy as np

## 폭염일수
f1 = open('C:/Users/김동현/Desktop/2학년 1학기 파이썬 수업/Python/프로젝트/온실가스_평균기온/폭염일수/전국 각 지역별 폭염일수 1973~2022.csv', encoding='cp949')  # CSV 파일 열어 f에 저장 
Hit = csv.reader(f1)  # reader() 함수로 읽기
header = next(Hit)  # 헤더 제거

# 데이터 저장을 위한 리스트 초기화
yeardata = []
hitday_00 = []  # 서울

hit_before1990 = 0
hit_1990th = 0
hit_2000th = 0
hit_2010th = 0
hit_2020th = 0

for row in Hit:
    year = int(row[0])
    hit_day = int(row[2])
    yeardata.append(year)
    hitday_00.append(hit_day)

print("년도별 : ", yeardata)
print("서울 폭염일수 : ", hitday_00)

f1.close()
